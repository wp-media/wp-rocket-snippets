# WP Rocket | Disable Contact form 7 optimization

Disables the optimizations WP Rocket applies for Contact form 7

Additional editing not required

Last tested with:

* WP Rocket 3.15.9
* WordPress 6.4.3
